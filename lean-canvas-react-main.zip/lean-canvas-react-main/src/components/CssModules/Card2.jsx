import styles from './Card2.module.css';

function Card2() {
  return <article className={styles.card}>Card2</article>;
}
export default Card2;
